library(testthat)
library(tornadodecimatestrailerpark)

test_check("tornadodecimatestrailerpark")
